# Every slot the league has prints, filled or not (DK I: QB WR WR RB RB TE FLX FLX K DEF · BN x5 · IR x1).
#        slot  name                 sta  pos  team  bubble radar            tri          blend  opponent  opp pts  mine final, theirs final
STARTS=[("QB","Tyler Shough","","QB","NO",None,None,None,"23.0","J. Love","22.7",0,1),
        ("RB","Travis Etienne Jr.","","RB","NO",None,("good","01"),None,"14.4","J. Williams","19.0",0,0),
        ("RB","Jaylen Warren","Q","RB","PIT",None,("caution","01"),("gold","1"),"17.4","Q. Judkins","16.9",0,0),
        ("WR","Drake London","","WR","ATL",None,None,None,"28.4","G. Wilson","14.6",1,0),
        ("WR","George Pickens","","WR","DAL",None,None,None,"15.0","M. Golden","21.0",0,1),
        ("TE","Travis Kelce","","TE","KC",None,None,None,"12.5","T. Kraft","6.6",0,1),
        ("FLX","Christian McCaffrey","","RB","SF",None,None,None,"24.2","R. Stevenson","13.4",0,0),
        ("FLX","TreVeyon Henderson","","RB","NE",None,None,None,"13.1","J. Taylor","25.1",0,0),
        ("K","Chris Boswell","","K","PIT",None,None,None,"7.2","W. Lutz","7.4",0,0),
        ("DEF","Vikings","","DEF","MIN",None,None,None,"7.6","Packers","-4.0",0,1)]
BENCH=[("BN","Kyle Monangai","","RB","CHI","red",None,("gold","1"),"10.5"),
       ("BN","Stefon Diggs","","WR","WAS","gold",None,None,"10.7"),
       ("BN","Dontayvion Wicks","","WR","PHI","grey",None,None,"9.1"),
       ("BN","Alvin Kamara","","RB","NO",None,None,None,"9.6"),
       ("BN","Kaelon Black","","RB","SF",None,None,None,"8.6")]
IRS=[("IR","Jayden Daniels","O","QB","WAS",None,None,None,None)]
