# THE SCOUT ENGINE v2 (Dom, Fri Oct 9 2026) — rebuilt from board.py v1 (kept as board_v1_backup.py).
# Gate 1: my team's holes, week by week, each slot measured against the opponent's man at the same slot that week
#         (his whole roster rolled forward to that week, not today's lineup).
# Gate 2: available players found by workload (or a door opening / a return), converted to points,
#         then the only question: can he incrementally improve my team — where, and when (week fill / season / playoffs).
# Gate 3: hunches — carried from hunches_DKI.csv, aged like everything else.
# Rules: no Yahoo projections; no drop suggestions; nothing assumed — every outside player the math leans on is checked
#        against the live Yahoo rosters; every bar says why it is what it is; run stamp + per-item age + kill condition.
# v2 valuation: proven players are judged mostly on real points (70/30 with workload) with last season as a prior;
#        unproven players lean on workload (40/60). One bad game can't sink a player (his worst game is lifted to his
#        next-worst). Recent games still count more.
import pandas as pd, numpy as np, re, json, os, math, collections, datetime as dt, sys
H="/home/claude/dksys/scout"; D="/home/claude/dksys/gate/fresh"; L="/home/claude/dksys/data/latest"
NOW,LAST=5,17; PLAYOFF={15,16,17}
LGK=[a for a in sys.argv[1:] if a.startswith("DK")]; LGK=LGK[0] if LGK else "DKI"
CFGS={
 "DKI":dict(lab="DK I",n=1,me=2,slots=["QB","WR","WR","RB","RB","TE","FLEX","FLEX","K","DEF"],intp=-2,ratt=.25,kick="flat",dfn="dk",median=False,
   teams={1:"JD",2:"Dark Knight I",3:"DIKFORE",4:"Rolling With Romo",5:"World Of Pain",6:"Punching Bag",7:"Raider nation",8:"Coin Toss Mike",9:"Mr. Rodgers' Neighborhood",10:"RoadDogg",11:"Kraft Beer TDs",12:"Remember the Tutens"},
   opp={5:7,6:5,7:10,8:6,9:9,10:4,11:12,12:8,13:1,14:11},urg={5:1.0,6:1.0,7:.9,8:.9,9:.75,10:.75,11:.75,12:.75,13:.75,14:.75,15:.4,16:.4,17:.4},
   record="1-3, 9th of 12",rost_at="Yahoo 9:50 AM PT",protect=["Travis Kelce","Kaelon Black"],pending="Mahomes claim, clears Oct 10"),
 "DKII":dict(lab="DK II",n=2,me=7,slots=["QB","WR","WR","WR","RB","RB","TE","FLEX","SUPERFLEX","K","DEF"],intp=-2,ratt=.25,kick="dist",dfn="std",median=False,
   teams={1:"Daejon Love Special",2:"Diddys Booty Butter",3:"RFFR",4:"FUCKING COWBOYS",5:"How 'Bout Them Points",6:"Trophy Hunter",7:"Dark Knight II",8:"RAIDER FAN",9:"Rams house",10:"Rated PG-18",11:"Hector Football",12:"Ground Game evan"},
   opp={5:4,6:3,7:12,8:6,9:11,10:2,11:9,12:1,13:5,14:10},urg={5:1.0,6:.95,7:.9,8:.9,9:.8,10:.8,11:.8,12:.8,13:.8,14:.8,15:.55,16:.55,17:.55},
   record="2-2, 8th of 12",rost_at="Yahoo 11:45 AM PT",protect=["Travis Kelce"],pending=""),
 "DKIII":dict(lab="DK III",n=3,me=2,slots=["QB","WR","WR","RB","RB","TE","FLEX","FLEX","DEF"],intp=-2,ratt=.25,kick=None,dfn="dk",median=False,
   teams={1:"Benchdad's Beach",2:"Dark Knight III",3:"Maly's Better Half",4:"Bad and Bougie 2.0",5:"Dawg Pound Eric",6:"The Deer Hunter Part Deux",7:"Press Coverage steph",8:"Rushin Roulette",9:"Dominique by 6",10:"Derek's Better Half",11:"Beachmom's Bench",12:"And A Goedert To You Sir",13:"Mr. Bobo",14:"Mrs. Bobo"},
   opp={5:12,6:3,7:6,8:1,9:3,10:13,11:8,12:6,13:12,14:5},urg={5:1.0,6:1.0,7:.9,8:.9,9:.75,10:.75,11:.75,12:.75,13:.75,14:.75,15:.4,16:.4,17:.4},
   record="1-3, 11th of 14",rost_at="Yahoo 11:45 AM PT",protect=[],pending=""),
 "DKIV":dict(lab="DK IV",n=4,me=6,slots=["QB","WR","WR","WR","RB","RB","TE","FLEX","SUPERFLEX","K","DEF"],intp=-1,ratt=0,kick="dist",dfn="std",median=True,
   teams={1:"Brad's Ballers",2:"Alan's Team",3:"Fly Eagles Fly",4:"Lin's Team",5:"Team Other",6:"Dark Knight IV",8:"Mr. Irrelevant",9:"Bad and Boujee",10:"Dream Killers",11:"Killer Ko-Gees"},
   opp={5:8,6:3,7:1,8:11,9:2,10:4,11:10,12:9,13:5,14:8},urg={5:.9,6:.9,7:.85,8:.85,9:.8,10:.8,11:.8,12:.8,13:.8,14:.8,15:.8,16:.8,17:.8},
   record="5-3, 5th of 10 (median game too)",rost_at="Yahoo 11:45 AM PT",protect=["Travis Kelce"],pending=""),
}
CF=CFGS[LGK]; ME=CF["me"]; TEAMNAMES=CF["teams"]; OPP=CF["opp"]; URG=CF["urg"]
SD=25.0
SLOTS=CF["slots"]; FLEXMAP={"FLEX":("RB","WR","TE"),"SUPERFLEX":("QB","RB","WR","TE")}; FLEXOK=("RB","WR","TE")
def okfor(s): return FLEXMAP.get(s,(s,))
TEAMFIX={"LAR":"LA"}
def tm(t): t=t.upper(); return TEAMFIX.get(t,t)
def norm(n):
    n=re.sub(r"[.'’\-]"," ",str(n).lower()); n=re.sub(r"\b(jr|sr|ii|iii|iv|v)\b","",n); return " ".join(n.split())
NOWPT=dt.datetime.now(dt.timezone(dt.timedelta(hours=-7)))
QUIET="--quiet" in sys.argv

# ================= inputs =================
R=[l.rstrip("\n").split("|") for l in open(f"{H}/dk{CF['n']}_rosters_live.txt") if l.strip() and not l.startswith("#")]
ROS=pd.DataFrame(R,columns=["tid","slot","name","team","pos","tag"]); ROS["tid"]=ROS.tid.astype(int); ROS["team"]=ROS.team.map(tm)
WAIV={}
for l in open(f"{H}/dk{CF['n']}_waivers.txt"):
    if l.startswith("#"): continue
    for it in l.strip().split("|"):
        if "/" in it: n,c=it.rsplit("/",1); WAIV[norm(n)]=c
pbp=pd.read_csv(f"{D}/play_by_play_2026.csv.gz",low_memory=False); pbp=pbp[pbp.season_type=="REG"]
st=pd.read_csv(f"{D}/stats_player_week_2026.csv",low_memory=False); st=st[st.season_type=="REG"].copy()
s25=pd.read_csv(f"{L}/stats_week_2025.csv",low_memory=False); s25=s25[s25.season_type=="REG"].copy()
inj=pd.read_csv(f"{D}/injuries_2026.csv"); ro=pd.read_csv(f"{D}/roster_2026.csv",low_memory=False)
sn=pd.read_csv(f"{D}/snap_counts_2026.csv"); sn=sn[sn.game_type=="REG"]
games=pd.read_csv(f"{L}/games.csv"); games=games[(games.season==2026)&(games.game_type=="REG")]
def most(df):
    g=lambda c: df[c].fillna(0) if c in df else 0
    return (g("receptions")+g("receiving_yards")/10+6*g("receiving_tds")+g("passing_yards")/25+6*g("passing_tds")+CF["intp"]*g("passing_interceptions")
            +g("rushing_yards")/10+6*g("rushing_tds")+CF["ratt"]*g("carries")-2*(g("rushing_fumbles_lost")+g("receiving_fumbles_lost")+g("sack_fumbles_lost"))
            +2*(g("passing_2pt_conversions")+g("rushing_2pt_conversions")+g("receiving_2pt_conversions")))
st["fp"]=most(st); s25["fp"]=most(s25)
P25=s25.groupby("player_display_name").agg(g=("week","nunique"),fp=("fp","sum")); P25["ppg"]=P25.fp/P25.g
P25=P25[P25.g>=6].ppg.to_dict(); P25={norm(k):v for k,v in P25.items()}

# work (expected points from targets / carries / throws)
b=lambda y: pd.cut(y,[0,2,5,10,20,40,100],labels=False,include_lowest=True)
pas=pbp[(pbp.play_type=="pass")&(pbp.two_point_attempt!=1)].copy(); pas["yb"]=b(pas.yardline_100); cpf=pas.cp.fillna(pas.complete_pass.mean())
tg=pas[pas.receiver_player_id.notna()].copy(); tdr=tg.groupby("yb").pass_touchdown.mean()
tg["xfp"]=cpf.reindex(tg.index)*(1+(tg.air_yards.fillna(0)+tg.xyac_mean_yardage.fillna(0))/10)+6*tg.yb.map(tdr).astype(float)
ru=pbp[(pbp.play_type=="run")&(pbp.two_point_attempt!=1)&pbp.rusher_player_id.notna()].copy(); ru["yb"]=b(ru.yardline_100)
rz=ru.groupby("yb").agg(y=("yards_gained","mean"),td=("rush_touchdown","mean")); ru["xfp"]=CF["ratt"]+ru.yb.map(rz.y).astype(float)/10+6*ru.yb.map(rz.td).astype(float)
pa=pas[pas.passer_player_id.notna()].copy(); ptd=pa.groupby("yb").pass_touchdown.mean(); pint=pa.interception.mean()
pa["xfp"]=cpf.reindex(pa.index)*(pa.air_yards.fillna(0)+pa.xyac_mean_yardage.fillna(0))/25+6*pa.yb.map(ptd).astype(float)+CF["intp"]*pint
X=pd.concat([tg[["receiver_player_id","week","xfp"]].rename(columns={"receiver_player_id":"id"}),ru[["rusher_player_id","week","xfp"]].rename(columns={"rusher_player_id":"id"}),
             pa[["passer_player_id","week","xfp"]].rename(columns={"passer_player_id":"id"})]).groupby(["id","week"]).xfp.sum()
# kickers & defenses in league scoring
kk=pbp[(pbp.field_goal_attempt==1)|(pbp.extra_point_attempt==1)].copy()
kk["kp"]=np.where(kk.field_goal_result=="made",(np.where(kk.kick_distance>=50,4,3) if CF["kick"]=="flat" else np.where(kk.kick_distance>=50,5,np.where(kk.kick_distance>=40,4,3))),0)+np.where(kk.extra_point_result=="good",1,0)-np.where(kk.extra_point_attempt.eq(1)&kk.extra_point_result.ne("good"),1,0)
KP=kk.groupby(["kicker_player_id","posteam","defteam","week"]).kp.sum().reset_index()
kname=st[st.position=="K"].drop_duplicates("player_id").set_index("player_id").player_display_name.to_dict()
fin=pbp.groupby(["game_id","week","home_team","away_team"]).agg(hs=("total_home_score","max"),as_=("total_away_score","max")).reset_index()
dd=pbp.copy(); dd["ret_td"]=((dd.touchdown==1)&(dd.td_team==dd.defteam)).astype(int); dd["fds"]=((dd.down==4)&(dd.fourth_down_failed==1)).astype(int)
dd["blk"]=dd.field_goal_result.eq("blocked").astype(int)+dd.punt_blocked.fillna(0)
DG=dd.groupby(["defteam","posteam","week"]).agg(sk=("sack","sum"),it=("interception","sum"),fr=("fumble_lost","sum"),td=("ret_td","sum"),sf=("safety","sum"),blk=("blk","sum"),fds=("fds","sum")).reset_index()
def pa_pts(p):
    if CF["dfn"]=="dk": return 17 if p==0 else 13 if p<=6 else 10 if p<=13 else 4 if p<=20 else 1 if p<=27 else -3 if p<=34 else -6
    return 10 if p==0 else 7 if p<=6 else 4 if p<=13 else 1 if p<=20 else 0 if p<=27 else -1 if p<=34 else -4
pts={}
for r in fin.itertuples(): pts[(r.home_team,r.week)]=r.as_; pts[(r.away_team,r.week)]=r.hs
DG["dp"]=DG.sk+2*(DG.it+DG.fr+DG.sf+DG.blk)+6*DG.td+(DG.fds if CF["dfn"]=="dk" else 0)+[pa_pts(pts.get((t,w),20)) for t,w in zip(DG.defteam,DG.week)]

# schedule & matchup difficulty (real points each defense allows to each position)
sched={};byes={}
for t in pd.unique(games[["home_team","away_team"]].values.ravel()):
    g=games[(games.home_team==t)|(games.away_team==t)]; sched[t]={int(r.week):r.away_team if r.home_team==t else r.home_team for r in g.itertuples()}
    byes[t]=[x for x in range(1,19) if x not in sched[t]]
allow={}
a=st[st.position.isin(["QB","RB","WR","TE"])].groupby(["opponent_team","position","week"]).fp.sum().reset_index().groupby(["opponent_team","position"]).fp.mean()
for (t,p),v in a.items(): allow[(t,p)]=v
for t,v in KP.groupby(["defteam","week"]).kp.sum().groupby("defteam").mean().items(): allow[(t,"K")]=v
for t,v in DG.groupby(["posteam","week"]).dp.sum().groupby("posteam").mean().items(): allow[(t,"DEF")]=v
RATIO={};TAG={}
for pos in ["QB","RB","WR","TE","K","DEF"]:
    s=pd.Series({k[0]:v for k,v in allow.items() if k[1]==pos}); q1,q2=s.quantile(1/3),s.quantile(2/3)
    for t,v in s.items(): RATIO[(t,pos)]=1+.5*(v/s.mean()-1); TAG[(t,pos)]="easy" if v>=q2 else "hard" if v<=q1 else "avg"

# ================= valuation v2 =================
def steady(v):
    """recent-weighted average where the single worst game is lifted to the next-worst (one bad night can't sink a player)"""
    v=[x for x in v if pd.notna(x)]
    if not v: return 0.0
    if len(v)>=4: lo=sorted(v)[1]; i=v.index(min(v)); v=v[:i]+[lo]+v[i+1:]
    return (.5*np.mean(v[-2:])+.5*np.mean(v)) if len(v)>=3 else float(np.mean(v))
inj5=inj[inj.week==inj.week.max()]; rep=inj5.set_index("gsis_id").report_status.dropna().to_dict()
prac=inj5.set_index("gsis_id").practice_status.dropna().to_dict()
injname=inj.dropna(subset=["report_primary_injury"]).drop_duplicates("gsis_id",keep="last").set_index("gsis_id").report_primary_injury.to_dict()
rs=ro[ro.week==ro.week.max()].set_index("gsis_id").status.to_dict()
SEASON_OUT={"de von achane"}
PL={}
for pid,g in st[st.position.isin(["QB","RB","WR","TE"])].groupby("player_id"):
    g=g.sort_values("week"); name=g.player_display_name.iloc[-1]; team=g.team.iloc[-1]; pos=g.position.iloc[-1]
    fp=list(g.fp); xv=[X.get((pid,w),0) for w in g.week]
    prior=P25.get(norm(name)); proven=prior is not None and prior>=8
    wr=.7 if proven else .4
    v26=wr*steady(fp)+(1-wr)*steady(xv)
    val=(len(fp)*v26+3*prior)/(len(fp)+3) if proven else v26          # last season counts like three games
    PL[(norm(name),team)]=dict(name=name,team=team,pos=pos,pid=pid,fwd=val,v26=v26,prior=prior,proven=proven,fp=fp,xv=xv,
        wks=list(g.week),last=int(g.week.max()),nflstat=rs.get(pid,""),rep=rep.get(pid,""),prac=prac.get(pid,""),inj=injname.get(pid,""))
for (pid,team),g in KP.groupby(["kicker_player_id","posteam"]):
    g=g.groupby("week").kp.sum(); n=kname.get(pid,pid)
    PL[(norm(n),team)]=dict(name=n,team=team,pos="K",fwd=steady(list(g.values)),fp=list(g.values),xv=[],wks=list(g.index),last=int(g.index.max()),nflstat="",rep="",prac="",inj="",proven=True,prior=None)
for t,g in DG.groupby("defteam"):
    g=g.groupby("week").dp.sum(); PL[("def "+t.lower(),t)]=dict(name=t+" defense",team=t,pos="DEF",fwd=steady(list(g.values)),fp=list(g.values),xv=[],wks=list(g.index),last=int(g.index.max()),nflstat="",rep="",prac="",inj="",proven=True,prior=None)
def find(name,team,pos):
    if pos=="DEF": return ("def "+team.lower(),team)
    k=norm(name)
    if (k,team) in PL: return (k,team)
    c=[key for key in PL if key[0]==k]; return c[0] if c else None

# ================= Yahoo ownership (for verification) =================
OWN={}
for r in ROS.itertuples():
    k=find(r.name,r.team,r.pos)
    OWN[(norm(r.name),r.team)]=(r.tid,r.slot,r.tag)
    if k: OWN[k]=(r.tid,r.slot,r.tag)
def owner(k): return OWN.get(k)

def back(p,ytag=""):
    if ytag in ("NA","CEL") or norm(p["name"]) in SEASON_OUT: return 99
    if ytag in ("IR","IR-R","PUP-R") or p.get("nflstat")=="RES": return max(p["last"]+5,NOW+1)
    if ytag=="O" or p.get("rep") in ("Out","Doubtful"): return NOW+1
    return NOW

# ================= ripples: a backup's boost ends when the man he replaced is due back =================
SNAP={(norm(r.player),r.team,int(r.week)):r.offense_pct for r in sn.itertuples()}
TEAMLAST=st.groupby("team").week.max().to_dict()
CLOSE={}
skill={k:p for k,p in PL.items() if p["pos"] in ("QB","RB","WR","TE")}
for k,p in skill.items():
    o=owner(k); yt=o[2] if o else ""; bw=back(p,yt); why=""
    if bw==99: continue
    if bw>NOW: why=("on IR" if (yt in ("IR","IR-R","PUP-R") or p["nflstat"]=="RES") else "listed Out")+(f" ({p['inj']})" if p["inj"] else "")
    elif p["last"]<TEAMLAST.get(p["team"],0) and p["nflstat"]!="RES" and p["inj"]: bw=NOW; why=f"missed his last game{' ('+p['inj']+')' if p['inj'] else ''}, practicing this week ({(p['prac'] or 'no report').replace(' Participation in Practice','').lower()})"
    else: continue
    full=[w for w in p["wks"] if SNAP.get((k[0],p["team"],w),1)>=.35]
    if not full: continue
    # the returning man must be a real role player, not a backup who saw garbage time (Lock, Cropper, Oliver, Moore)
    starter_wks=[w for w in p["wks"] if SNAP.get((k[0],p["team"],w),0)>=(.7 if p["pos"]=="QB" else .5)]
    if not starter_wks or p["fwd"]<6 or (p["pos"]=="QB" and p["last"] not in starter_wks): continue
    for k2,m in skill.items():
        if k2==k or m["team"]!=p["team"] or m["pos"]!=p["pos"]: continue
        if p["fwd"]<.5*m["fwd"]: continue
        def blend(f,x): return (.7*f+.3*x) if m["proven"] else (.4*f+.6*x)
        withv=[blend(f,x) for f,x,w in zip(m["fp"],m["xv"],m["wks"]) if w in full]
        wo=[blend(f,x) for f,x,w in zip(m["fp"],m["xv"],m["wks"]) if w not in full]
        if not wo: continue
        wv=np.mean(withv) if withv else (0.0 if p["pos"]=="QB" else .5*np.mean(wo))
        if m["proven"] and m["prior"]: wv=(len(withv)*wv+3*m["prior"])/(len(withv)+3) if withv else wv
        if np.mean(wo)-wv>=2 and (k2 not in CLOSE or CLOSE[k2]["week"]>bw):
            CLOSE[k2]=dict(week=bw,who=p["name"],whokey=k,after=wv,before=np.mean(wo),why=why)

def weekly(p,x,ytag=""):
    if x in byes.get(p["team"],[]) or x<back(p,ytag): return 0.0
    v=p["fwd"]; ck=(norm(p["name"]),p["team"])
    if ck in CLOSE and x>=CLOSE[ck]["week"]: v=min(v,CLOSE[ck]["after"])
    return v*RATIO.get((sched[p["team"]].get(x),p["pos"]),1.0)

TEAMS=collections.defaultdict(list); MISS=[]
for r in ROS.itertuples():
    k=find(r.name,r.team,r.pos)
    if k is None: MISS.append(f"{r.name} ({r.team}, {r.tag or 'no tag'})"); continue
    TEAMS[r.tid].append(dict(key=k,name=r.name,pos=r.pos,ytag=r.tag,slot=r.slot))
taken=set(OWN)
def vals(m,x): return weekly(PL[m["key"]],x,m["ytag"])
def lineup(members,x):
    pool=sorted(((vals(m,x),m["pos"],i) for i,m in enumerate(members)),reverse=True); used=set(); out=[]
    for s in SLOTS:
        ok=okfor(s)
        pick=next(((v,i) for v,p,i in pool if i not in used and p in ok),(0.0,None))
        if pick[1] is not None: used.add(pick[1])
        out.append((s,pick[1],pick[0]))
    srt=sorted(out,key=lambda o:(SLOTS.index(o[0]),-o[2])); cnt=collections.Counter(); lab=[]
    for s,i,v in srt: cnt[s]+=1; lab.append((s+(str(cnt[s]) if SLOTS.count(s)>1 else ""),i,v))
    return lab
def total(members,x): return sum(v for _,_,v in lineup(members,x))
WEEKS=list(range(NOW,LAST+1)); MINE=TEAMS[ME]
LU={x:lineup(MINE,x) for x in WEEKS}; my={x:sum(v for _,_,v in LU[x]) for x in WEEKS}
OLU={x:lineup(TEAMS[OPP[x]],x) for x in WEEKS if x in OPP}
opp={x:(sum(v for _,_,v in OLU[x]) if x in OLU else float(np.median([total(TEAMS[t],x) for t in TEAMS if t!=ME]))) for x in WEEKS}
def winp(m): return .5*(1+math.erf(m/(SD*math.sqrt(2))))
def _lv(m): return math.exp(-.5*(m/SD)**2)/(SD*math.sqrt(2*math.pi))
MED={x:float(np.median([total(TEAMS[t],x) for t in TEAMS if t!=ME])) for x in WEEKS} if CF["median"] else {}
LEV={x:URG[x]*(_lv(my[x]-opp[x])+(_lv(my[x]-MED[x]) if CF["median"] else 0)) for x in WEEKS}

# ================= GATE 1: my holes, slot vs slot =================
def fullstrength():
    pool=sorted(((PL[m["key"]]["fwd"],m["pos"],i) for i,m in enumerate(MINE) if m["slot"]!="IR" and m["ytag"] not in ("NA","CEL")),reverse=True)
    used=set(); out=[]
    for s_ in SLOTS:
        ok=okfor(s_); v,p,i=next(((v,p,i) for v,p,i in pool if i not in used and p in ok)); used.add(i); out.append((s_,i,v))
    cnt=collections.Counter(); d={}
    for s_,i,v in sorted(out,key=lambda o:(SLOTS.index(o[0]),-o[2])): cnt[s_]+=1; d[s_+(str(cnt[s_]) if SLOTS.count(s_)>1 else "")]=(MINE[i]["name"],v,i)
    return d
FULL=fullstrength()
def where(name,x):
    for lab,i,v in LU[x]:
        if i is not None and MINE[i]["name"]==name: return lab
    return None
HOLES=collections.defaultdict(list)
for x in WEEKS:
    theirs={lab:(TEAMS[OPP[x]][i]["name"] if i is not None else None,v) for lab,i,v in OLU[x]} if x in OLU else {}
    for lab,i,v in LU[x]:
        fn,fv,fi=FULL[lab]; who=MINE[i]["name"] if i is not None else None
        tn,tv=theirs.get(lab,(None,None)); reasons=[]; kind="short"
        if who is None or v==0: kind="empty"; reasons.append(f"{fn} on bye" if x in byes.get(PL[MINE[fi]["key"]]["team"],[]) else "slot empty")
        else:
            p=PL[MINE[i]["key"]]; ck=MINE[i]["key"]
            if who!=fn:
                w_=where(fn,x)
                pf=PL[MINE[fi]["key"]]
                st_=("moves up to "+w_) if w_ else "on bye" if x in byes.get(pf["team"],[]) else "out" if x<back(pf,MINE[fi]["ytag"]) else f"sits for a better matchup ({who})"
                reasons.append(f"{fn} {st_}" + ("" if st_.startswith("sits") else f", {who} slides in"))
            if ck in CLOSE and x>=CLOSE[ck]["week"]: reasons.append(f"{who} fades to ~{CLOSE[ck]['after']:.0f} once {CLOSE[ck]['who']} is back")
            o=sched[p["team"]].get(x)
            if TAG.get((o,p["pos"]))=="hard": reasons.append(f"hard matchup vs {o}")
        short_full=fv-v; short_opp=(tv-v) if tv is not None else 0
        if kind=="empty" or (short_full>=2 and v<.85*fv) or (short_opp>=4 and reasons):
            HOLES[lab].append(dict(week=x,who=who,val=v,full=fv,fullname=fn,them=tn,themv=tv,reasons=reasons,kind=kind))
# ================= GATE 2: available players — workload / door / return → points → where do they improve my team =================
def gate2_reason(k,p):
    o=owner(k); r=[]
    if back(p)>NOW: r.append(f"due back Wk {back(p)} ({'IR minimum' if p['nflstat']=='RES' else 'listed Out'})")
    mates=[m for kk_,m in skill.items() if m["team"]==p["team"] and m["pos"]==p["pos"] and kk_!=k and back(m,(owner(kk_) or (0,0,''))[2])>NOW]
    if mates and len(p["xv"])>=2 and np.mean(p["xv"][-2:])>np.mean(p["xv"][:-2] or [0])+2: r.append(f"door open: {mates[0]['name']} out")
    if len(p["xv"])>=3:
        e,l=np.mean(p["xv"][:-2]),np.mean(p["xv"][-2:])
        if l-e>=3 and l>=1.25*e: r.append(f"workload up from {e:.1f} to {l:.1f} expected a game")
    if len(p["fp"])>=2 and np.mean(p["xv"] or [0])-np.mean(p["fp"])>=3: r.append(f"getting {np.mean(p['xv']):.1f} expected but scoring {np.mean(p['fp']):.1f}")
    return r
cands=[k for k in PL if k not in taken and PL[k]["fwd"]>=(5 if PL[k]["pos"] in ("K","DEF") else 6) and norm(PL[k]["name"]) not in SEASON_OUT]
G2=[]
for k in cands:
    p=PL[k]; newm=dict(key=k,name=p["name"],pos=p["pos"],ytag="",slot="BN")
    team2=MINE+[newm]                                   # no drop: an add is priced as "if a seat opens"
    g={x:total(team2,x)-my[x] for x in WEEKS}
    good=[x for x in WEEKS if g[x]>=1.5]
    if not good: continue
    wins=sum(LEV[x]*g[x] for x in WEEKS)
    slots=collections.Counter(lab for x in good for lab,i,v in lineup(team2,x) if i is not None and team2[i]["key"]==k)
    lvl=slots.most_common(1)[0][0] if slots else "?"
    pk=[x for x in good if x in PLAYOFF]
    kind="season-long" if len(good)>=.6*len(WEEKS) else ("playoffs" if pk and len(good)==len(pk) else "fill")
    G2.append(dict(act=len(p["fp"])>=2,k=k,p=p,g=g,good=good,wins=wins,lvl=lvl,kind=kind,why=gate2_reason(k,p),acq=("waivers, clears "+WAIV[k[0]]) if k[0] in WAIV else ("waivers, clears Oct 14" if PL[k]["team"] in ("TB","DAL") else "free agent")))
G2.sort(key=lambda e:-e["wins"])

# ================= life cycle =================
SF=f"{H}/scout_state_{LGK}.json"
state=json.load(open(SF)) if os.path.exists(SF) else {"items":{},"kills":{}}
state.setdefault("kills",{})
state["kills"].setdefault("Tyler Higbee",{"type":"soft","on":"2026-10-09","until_week":NOW+2,"why":"Dom: Ferguson back Wk 8, three Rams TEs by the playoffs"})
def kills_str():
    ks=[(n,k) for n,k in state["kills"].items() if killed(n)]
    return " · Killed: "+", ".join(f"{n.split()[-1]} ({'soft, two games' if k['type']=='soft' else 'season'})" for n,k in ks) if ks else ""
def killed(n): k=state["kills"].get(n); return bool(k) and (k["type"]=="hard" or NOW<=k.get("until_week",0))
def age(first):
    d=(NOWPT.date()-dt.date.fromisoformat(first)).days
    return "added today" if d==0 else "added yesterday" if d==1 else f"added {d} days ago"
def wk(lst):
    if not lst: return ""
    runs=[];s=p_=lst[0]
    for x in lst[1:]+[None]:
        if x is None or x!=p_+1: runs.append(f"Week {s}" if s==p_ else f"Weeks {s}-{p_}"); s=x
        p_=x if x is not None else p_
    return ", ".join(runs)
def recline(e):
    p=e["p"]; sc=", ".join(f"{v:.0f}" if p['pos'] in ('K','DEF') else f"{v:.1f}" for v in p["fp"])
    when=wk(e["fill_weeks"]) if e.get("fill_weeks") else wk(e["good"])
    why="; ".join(e["why"]) if e["why"] else f"his current level, ~{p['fwd']:.0f} a game, improves the team"
    return f"{p['name']}, {p['team']} — scored {sc} — {e['acq']} — {why}; helps {when}"

# ================= build the board =================
def fills_for(okpos,w):
    f=[]
    for e in G2:
        if e["p"]["pos"] not in okpos or killed(e["p"]["name"]) or not e["act"]: continue
        fw=[x for x in w if e["g"][x]>=1.5]
        if not fw: continue
        f.append((sum(LEV[x]*e["g"][x] for x in w),dict(e,fill_weeks=fw)))
    return sorted(f,key=lambda t:-t[0])
needs=[]
def add_need(lab,kind,w,bar,why,lst,okpos,ideal=None):
    fl=fills_for(okpos,w); stake=sum(LEV[h["week"]]*max(h["full"]-h["val"],(h["themv"] or 0)-h["val"],0) for h in lst) if lst else 0
    if kind=="season-long": stake=sum(LEV[x]*(FULL[lab][1]-bar) for x in WEEKS)
    scarcity=1/(1+min(len(fl),6)*.35)
    needs.append(dict(lab=lab,kind=kind,weeks=w,bar=bar,ideal=ideal,why=why,holes=lst,fills=fl[:2],n=len(fl),stake=stake,prio=stake*scarcity))
for lab,lst in HOLES.items():
    pos=lab.rstrip("12"); okpos=okfor(pos)
    fn,fv,fi=FULL[lab]; single=SLOTS.count(pos)==1
    emp=[h for h in lst if h["kind"]=="empty"]; sh=[h for h in lst if h["kind"]!="empty"]
    if emp:                                                 # one need per slot, all its empty weeks together
        rs=" · ".join((f"Wk {h['week']} " if len(emp)>1 else "")+h['reasons'][0] for h in emp)
        add_need((pos+"2") if single else lab,"fill",[h["week"] for h in emp],0,f"{rs}; ideally ~{fv:.0f} ({fn}{"'" if fn.endswith('s') else "'s"} level)",emp,okpos,ideal=fv)
    if sh:
        add_need(lab,"fill",[h["week"] for h in sh],float(np.mean([h["val"] for h in sh])),None,sh,okpos)
# season-long: the slot's regular holder is about to fade (the man he replaced is coming back)
for lab,(fn,fv,fi) in FULL.items():
    k=MINE[fi]["key"]
    if k in CLOSE and CLOSE[k]["week"]<=NOW+1:
        c=CLOSE[k]; pos=lab.rstrip("12"); okpos=okfor(pos)
        add_need(lab,"season-long",WEEKS,c["after"],f"replacing a ~{c['before']:.0f}: {fn} becomes ~{c['after']:.0f} once {c['who']} is back ({c['why']}) — anything over {c['after']:.0f} is an improvement",[],okpos)
needs.sort(key=lambda n:-n["prio"])
# ================= print =================
out=[]
P=out.append
P(f"THE SCOUT — {CF['lab']} — run {NOWPT.strftime('%a %b %d, %I:%M %p PT')} — record {CF['record']}")
P("Inputs: all 12 rosters + waivers (Yahoo, 9:50-9:55 AM) · stats & play-by-play (nflverse 7:40 AM; Weeks 1-4 + Thursday's Week 5) · 2025 season as a prior · no Yahoo projections")
P("Read depth: 4 games of 2026 data — directional, not settled.\n")
P("GATE 1 — YOUR NEEDS, IN PRIORITY ORDER")
for n,nd in enumerate(needs,1):
    w=nd["weeks"]; when="season-long" if nd["kind"]=="season-long" else wk(w)+" fill"
    first=state["items"].setdefault(f"need:{nd['lab']}:{when}",NOWPT.date().isoformat())
    mark="RED" if (min(w)<=NOW+1 and nd["n"]>0) or (nd["kind"]=="season-long") else "GOLD"
    bar=f"ideally beat {nd['bar']:.0f}" if nd["bar"]>0 else f"anything beats 0, ideally ~{nd['ideal']:.0f}"
    P(f"{n}. [{mark}] {nd['lab']}, {when}, {bar}  ({age(first)})")
    if nd["why"]: P(f"   Why: {nd['why']}.")
    else:
        rs_=[]
        for h in nd["holes"]: rs_.append(f"Wk {h['week']}: {h['who']} ~{h['val']:.0f}"+(f" ({'; '.join(h['reasons'])})" if h['reasons'] else ""))
        P(f"   Why: at full strength this slot gives ~{nd['holes'][0]['full']:.0f} ({nd['holes'][0]['fullname']}). "+" · ".join(rs_)+".")
    opps=[h for h in nd["holes"] if h["them"]]
    if opps: P("   Man across from you: "+" · ".join(f"Wk {h['week']} {h['them']} ~{h['themv']:.0f} vs your {h['who'] or 'nobody'} ~{h['val']:.0f}" for h in opps[:4]))
    if not nd["fills"]: P("   No recommendation — nobody available fits.")
    else:
        for j,(val,e) in enumerate(nd["fills"],1): P(f"   {j}) {recline(e)}")
    P(f"   Kill when: {'its week passes' if nd['kind']!='season-long' else 'the man he replaced is back and the fade is confirmed in real games, or a pickup fills it'}.")
P("\nGATE 2 — AVAILABLE PLAYERS WHO COULD INCREMENTALLY IMPROVE THE TEAM (found by workload / door / return; ranked by wins added)")
shown=0
for e in G2:
    if killed(e["p"]["name"]) or not e["why"]: continue
    if not e["act"]: e=dict(e,why=e["why"]+["one game only — flag, not act"])
    first=state["items"].setdefault("g2:"+e["p"]["name"],NOWPT.date().isoformat()); shown+=1
    kind="season-long" if e["kind"]=="season-long" else ("playoffs" if e["kind"]=="playoffs" else wk(e["good"]))
    P(f"{shown}. [{'RED' if min(e['good'])<=NOW+1 and e['wins']>=.1 else 'GOLD'}] {e['lvl']}, {kind} — {recline(e)}  ({age(first)})")
    if shown>=8: break
if shown==0: P("   none this run")
hf=f"{H}/hunches_{LGK}.csv"
P("\nGATE 3 — HUNCHES"); P(open(hf).read().strip() if os.path.exists(hf) and len(open(hf).read().strip().splitlines())>1 else "   none written yet")
P("\nCHECKED, NOT ASSUMED — players the math leans on, verified against the live Yahoo rosters (9:50 AM) and the injury report:")
for k,c in CLOSE.items():
    o=owner(k)
    if not o or o[0]!=ME: continue
    r=owner(c["whokey"])
    status=f"rostered by {TEAMNAMES[r[0]]} ({r[1]}{', Yahoo tag '+r[2] if r[2] else ''})" if r else "NOT ROSTERED — available in "+CF["lab"]
    pr=PL[c["whokey"]]
    P(f" • {PL[k]['name']}: ~{c['before']:.0f} → ~{c['after']:.0f} from Week {c['week']}, because {c['who']} ({c['why']}) is due back. {c['who']}: {status}; practice: {pr['prac'] or 'no report'}.")
P("\nPROTECTED (Dom's call): "+", ".join(CF["protect"])+kills_str()+(" · PENDING: "+CF["pending"] if CF["pending"] else ""))
if MISS: P("No 2026 games, not scored: "+", ".join(MISS))
# ---- structured board for the Dispatch page (Dispatch voice: no "you/your", one decimal, capitalized labels)
BOARD=dict(league=CF["lab"],run=NOWPT.isoformat(),run_str=NOWPT.strftime('%a %b %d, %I:%M %p PT').replace(' 0',' '),
           depth=f"Built from real points and workload — four games of 2026 data, so read it as a direction · rosters {CF['rost_at']} · stats nflverse 7:40 AM PT",
           gate1=[],gate2=[],gate3=[],checked=[],
           footer=(("Protected (Dom's call): "+", ".join(CF["protect"])) if CF["protect"] else "Protected: none")+kills_str()+(" · Pending: "+CF["pending"] if CF["pending"] else ""))
def sn_(n):
    if not n: return "nobody"
    if n.split()[0] in ("New","Los","San","Green","Kansas","Tampa","Las"): return n
    parts=[x for x in n.split() if x.rstrip(".") not in ("Jr","Sr","II","III","IV","V")]; return parts[-1] if parts else n
def short_r(r):
    r=r.replace(" Jr.","").replace(" Sr.","").replace(" II","").replace(" III","")
    r=re.sub(r"([A-Z][a-z'A-Z.\-]+ )+([A-Z][a-zA-Z'\-]+)",lambda m:m.group(2),r)
    return re.sub(r"(\S+) sits for a better matchup \(([^)]+)\)",r"\1 has a worse matchup",r)
def wkc(lst):
    runs=[];s_=p_=lst[0]
    for x in lst[1:]+[None]:
        if x is None or x!=p_+1: runs.append(f"{s_}" if s_==p_ else f"{s_}-{p_}"); s_=x
        p_=x if x is not None else p_
    return ("Week " if len(lst)==1 else "Weeks ")+", ".join(runs)
_NOUN={"RB":"the Backfield","WR":"the Receiving Corps","TE":"the Tight End Spot","QB":"the Quarterback Spot","K":"the Kicker Spot",
       "DEF":"the Defense","FLEX":"the Flex","SUPERFLEX":"the Superflex"}
def _cause(r):
    if "on bye" in r: return "bye"
    if "hard matchup" in r: return "matchup"
    if "fades to" in r: return "fade"
    if r=="slot empty": return "empty"
    return "shuffle"
def headline(nd):
    """the plain-language headline that leads each need: names the problem; the slot code rides behind it"""
    pos=nd["lab"].rstrip("12"); n=_NOUN.get(pos,pos); N=n[0].upper()+n[1:]; one=len(nd["weeks"])==1
    if nd["kind"]=="season-long": return f"{N} Won't Hold"
    if nd["bar"]==0: return "The Defense Goes Dark" if pos=="DEF" else ("The Kicker Goes Dark" if pos=="K" else f"The {nd['lab']} Slot Goes Empty")
    cs=[_cause(h["reasons"][0]) if h["reasons"] else "shuffle" for h in nd["holes"]]
    top=max(set(cs),key=lambda x:(cs.count(x),x=="bye"))
    if top=="bye": return f"A Bye Hits {n}" if one else f"Byes Hit {n}"
    if top=="matchup": return f"A Tough Draw for {n}" if one else f"Tough Draws for {n}"
    if top=="fade": return f"{N} Fades"
    return f"{N} Runs Thin"
def cap_when(w): return "Season-Long" if w=="season-long" else w.replace("fill","Fill")
def _pick(e,need_red,w):
    p=e["p"]; sc=", ".join(f"{v:.0f}" if p['pos'] in ('K','DEF') else f"{v:.1f}" for v in p["fp"])
    why="; ".join(e["why"]) if e["why"] else f"current level ~{p['fwd']:.1f} a game"
    fw=e.get("fill_weeks") or e["good"]
    urg="red" if (need_red and min(fw)<=NOW+1) else "gold"
    return dict(name=p["name"].replace(" defense"," DEF"),team=p["team"],scores=sc,acq=e["acq"].replace("free agent","Free agent").replace("waivers,","Waivers,"),
                why=why[0].upper()+why[1:],when=wk(fw).replace("Week","Wk").replace("Weeks","Wks"),urg=urg)
# ---- LIFE CYCLE + ARCHIVE (Dom, Oct 9): the Signal's rule on the spyglass. A need keeps one stable key per slot and
# kind; every day it shows is recorded. First day = splat; then a zero-padded day count. A need that left and came back
# prints its fresh count over the gap it was gone (01/12), never the splat. Nothing is deleted: every run appends to
# scout_archive_<league>.jsonl, so any item can be recalled after it leaves the page.
TODAY=NOWPT.date()
state.setdefault("life",{})
def life(key):
    L=state["life"].setdefault(key,{"eps":[]}); t=TODAY.isoformat()
    if L["eps"] and L["eps"][-1][1]>=(TODAY-dt.timedelta(days=1)).isoformat():
        L["eps"][-1][1]=max(L["eps"][-1][1],t)
    elif not L["eps"] or L["eps"][-1][1]!=t: L["eps"].append([t,t])
    st=dt.date.fromisoformat(L["eps"][-1][0]); age=(TODAY-st).days
    gap=None
    if len(L["eps"])>1: gap=(st-dt.date.fromisoformat(L["eps"][-2][1])).days
    return dict(age=age,gap=gap,first=L["eps"][0][0])
season_labs={nd["lab"] for nd in needs if nd["kind"]=="season-long"}
picked=set()
for nd in needs:
    if nd["kind"]!="season-long" and nd["lab"] in season_labs and nd["bar"]>0:
        continue                                            # folded into that slot's season-long line
    w=nd["weeks"]
    if nd["kind"]=="fill" and len(w)>=.6*len(WEEKS): nd["kind"]="season-long"
    when="season-long" if nd["kind"]=="season-long" else wkc(w)+" fill"
    key=f"need:{nd['lab']}:{nd['kind']}:{'empty' if nd['bar']==0 else 'short'}"; LF=life(key); first=LF["first"]
    red=(min(w)<=NOW+1 and nd["n"]>0) or (nd["kind"]=="season-long")
    tgt=nd["bar"] if nd["bar"]>0 else nd["ideal"]
    if nd["why"]: why=nd["why"].replace(f" — anything over {nd['bar']:.0f} is an improvement","")
    else:
        hs=nd["holes"]
        why=" · ".join(f"Wk {h['week']} {sn_(h['who'])} ~{h['val']:.1f}"+(f" ({short_r(h['reasons'][0])})" if h['reasons'] else "") for h in hs)
        why=f"Full strength ~{hs[0]['full']:.1f} ({sn_(hs[0]['fullname'])}). "+why
    if nd["kind"]=="season-long":
        extra=[n2 for n2 in needs if n2["lab"]==nd["lab"] and n2["kind"]!="season-long" and n2["bar"]>0]
        if extra:
            worst=sorted(extra[0]["holes"],key=lambda h:h["val"])[:2]
            why+=". Worst weeks: "+", ".join(f"Wk {h['week']} {sn_(h['who'])} ~{h['val']:.1f}" for h in worst)
    if nd["bar"]==0: why+=" — anything beats zero"
    across=" · ".join(f"Wk {h['week']} {sn_(h['them'])} ~{h['themv']:.1f} vs {sn_(h['who'])} ~{h['val']:.1f}" for h in nd["holes"] if h["them"])[:160]
    picks=[_pick(e,red,w) for _,e in nd["fills"]]; picked|={p["name"] for p in picks}
    BOARD["gate1"].append(dict(mark="red" if red else "gold",first=first,key=key,age=LF["age"],gap=LF["gap"],head=headline(nd),title=f"{nd['lab']}, {cap_when(when)}",target=f"Target {tgt:.1f} pts",
        why=(why[0].upper()+why[1:]).rstrip(".")+".",across=across,picks=picks,none=None if picks else "No recommendation — nobody available fits.",
        kill=("Drops Off After Wk "+str(max(w))) if nd["kind"]!="season-long" else "Drops Off When Filled"))
for e in G2:
    if killed(e["p"]["name"]) or not e["why"] or e["p"]["name"].replace(" defense"," DEF") in picked: continue
    LF=life("g2:"+e["p"]["name"]); first=LF["first"]
    kind="Season-Long" if e["kind"]=="season-long" else ("Playoffs" if e["kind"]=="playoffs" else wkc(e["good"]))
    BOARD["gate2"].append(dict(mark="red" if min(e['good'])<=NOW+1 and e['wins']>=.1 else "gold",first=first,age=LF["age"],gap=LF["gap"],title=f"{e['lvl']}, {kind}",pick=_pick(e,False,e["good"]),act=e["act"]))
    if len(BOARD["gate2"])>=4: break
for k,c in CLOSE.items():
    o=owner(k)
    if not o or o[0]!=ME: continue
    r=owner(c["whokey"])
    BOARD["checked"].append(f"{sn_(PL[k]['name'])} ~{c['before']:.1f} to ~{c['after']:.1f} from Wk {c['week']} — {c['who']} checked: "+
        (f"rostered by {TEAMNAMES[r[0]]}{' (IR)' if r[1]=='IR' else ''}" if r else "NOT rostered — available"))
from collections import Counter as _Ctr
# Oct 9 (Dom): a count only when the SAME slot repeats (DEF + DEF2, K + K2) - never RB1 vs RB2 or WR1 vs WR2
_fam=lambda it: re.sub(r"2$","",it["title"].split(",")[0]) if it["title"].split(",")[0].rstrip("2") in ("QB","TE","K","DEF","SUPERFLEX") else it["title"].split(",")[0]
BOARD["gate1"].sort(key=lambda it: 0 if it["mark"]=="red" else 1)   # Oct 9 (Dom): every red spyglass first, then gold; priority holds inside each
_cnt=_Ctr(_fam(it) for it in BOARD["gate1"])
for it in BOARD["gate1"]: it["rep"]=_cnt[_fam(it)] if _cnt[_fam(it)]>1 else 0
with open(f"{H}/scout_archive_{LGK}.jsonl","a") as _af:
    _af.write(json.dumps(dict(run=NOWPT.isoformat(),league=CF["lab"],
        gate1=[{k:it.get(k) for k in ("key","mark","head","title","target","why","kill","age","gap")}|{"picks":[p["name"] for p in it["picks"]]} for it in BOARD["gate1"]],
        gate2=[dict(title=it["title"],mark=it["mark"],name=it["pick"]["name"],why=it["pick"]["why"]) for it in BOARD["gate2"]]))+"\n")
json.dump(BOARD,open(f"{H}/scout_board_{LGK}.json","w"),indent=1)
json.dump(state,open(SF,"w"),indent=1)
REPORT="\n".join(out)
if not QUIET: print(REPORT)
pd.to_pickle(dict(PL=PL,TEAMS=TEAMS,LU=LU,OLU=OLU,my=my,opp=opp,needs=needs,G2=G2,CLOSE=CLOSE,FULL=FULL),f"{H}/scout_v2_{LGK}.pkl")
