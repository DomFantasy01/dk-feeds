"""METER DATA — the one data layer behind the mountains page (Dark Knight Dispatch page 1). Built Thu Oct 8 2026.
Run:  python3 meter_data.py            (week read from the NFL schedule: first week with unplayed games)
      python3 meter_data.py 5          (force a week)
Writes  /home/claude/dksys/data/latest/meter/meter_wk<W>.json   and   alarm_wk<W>.json
Nothing in here is typed by hand per week. Every number carries whose it is and when it was pulled.

THREE NEEDLES per league (Dom, Oct 8):
  CENTER = Yahoo's own posted win %, exactly as on Yahoo's matchup page.
  LEFT   = GOTHAM: Gotham's points for every starter on both sides, through the win-probability math below.
  RIGHT  = SLEEPER: Sleeper's public projections, priced in the league's own scoring, through the same math.
  Kickers and defenses: Sleeper's numbers in both Gotham and Sleeper totals (Oct 8 test: nobody beats a flat average there).
  A starter Gotham cannot model (no NFL games on record) falls back to Yahoo's number and is counted as a fallback.
WIN-PROBABILITY MATH (unchanged from the page): banked points count as banked; for everyone still to play, the spread is
  each slot's sigma (QB 8, RB 8, WR 8.5, TE 6.5, K 4.5, DEF 6.5) with correlation .14 inside a side; chance = Phi(gap / spread).
ALARM: any source missing, older than its limit, or short on rows/teams -> listed in alarm_wk<W>.json and on the page.
"""
import os, sys, re, json, glob, math, datetime as dt
import pandas as pd
sys.path.insert(0, '/home/claude/dksys/gather'); from names import norm
sys.path.insert(0, '/home/claude/src/forecast'); import fc_model as FM

ROOT = '/home/claude/dksys/data/latest/'
FEEDS = '/home/claude/domfantasy01/dk-feeds/feeds/'
ENGINE = '/home/claude/dksys/engine/'
OUT = ROOT + 'meter/'
PT = dt.timezone(dt.timedelta(hours=-7))          # Pacific daylight time until Nov 1
NOW = dt.datetime.now(PT)

LEAGUES = {   # league facts that do not change week to week
 'DK I':   dict(id='269381',  me='Dark Knight I',   k=1, full='TheMostImportantThingInLife', slots=10),
 'DK II':  dict(id='1519795', me='Dark Knight II',  k=2, full='Winners and Sinners',         slots=11),
 'DK III': dict(id='1507991', me='Dark Knight III', k=3, full='Hers and His Version 2.0',    slots=9),
 'DK IV':  dict(id='864215',  me='Dark Knight IV',  k=4, full='Murrieta NextDoor',           slots=11),
}
SIG = {'QB': 8.0, 'RB': 8.0, 'WR': 8.5, 'TE': 6.5, 'K': 4.5, 'DEF': 6.5}; RHO = .14
SCORING = json.load(open(ROOT + 'yahoo/scoring/scoring_audit_oct1.json'))
TEAMFIX = {'WSH': 'WAS', 'JAC': 'JAX', 'LA': 'LAR'}
def T(t): t = str(t).upper(); return TEAMFIX.get(t, t)

alarms, sources, notes = [], {}, []
def stamp(key, path, limit_h, rows=None, need=None, note=''):
    """record a source with its age; raise an alarm if missing, stale or short"""
    if not path or not os.path.exists(path):
        alarms.append(f'{key}: MISSING ({path})'); sources[key] = dict(status='MISSING', path=path); return
    m = dt.datetime.fromtimestamp(os.path.getmtime(path), PT)
    age = (NOW - m).total_seconds() / 3600
    st = 'OK'
    if age > limit_h: st = 'STALE'; alarms.append(f'{key}: STALE - {age:.1f} h old (limit {limit_h} h)')
    if need is not None and rows is not None and rows < need:
        st = 'SHORT'; alarms.append(f'{key}: SHORT - {rows} of {need}')
    sources[key] = dict(status=st, path=path, pulled_pt=m.strftime('%a %b %d %I:%M %p PT'), age_h=round(age, 1), rows=rows, need=need, note=note)

def file_time(path):
    """pull time written in a file's own name (…_thu1050 / …T1830Z) beats the disk time when present"""
    return None

# ---------------------------------------------------------------- the week
G = pd.read_csv(ROOT + 'games.csv', low_memory=False); G = G[(G.season == 2026) & (G.game_type == 'REG')]
WEEK = int(sys.argv[1]) if len(sys.argv) > 1 else int(G[G.result.isna()].week.min())
GW = G[G.week == WEEK]
stamp('nfl_schedule', ROOT + 'games.csv', 30, rows=len(GW), need=len(GW), note=f'week {WEEK}: {len(GW)} games')

# game windows from this week's real kickoffs (nflverse gametime is Eastern); same rules as the page always used
DORD = {'Thursday': 0, 'Friday': 1, 'Saturday': 2, 'Sunday': 3, 'Monday': 4}
DAB = {'Thursday': 'THU', 'Friday': 'FRI', 'Saturday': 'SAT', 'Sunday': 'SUN', 'Monday': 'MON'}
def mins(t): return int(t[:2]) * 60 + int(t[3:5])
slots = sorted({(r.weekday, r.gametime) for r in GW.itertuples()}, key=lambda k: (DORD[k[0]], mins(k[1])))
WINS = []
for d, t in slots:
    if WINS and WINS[-1]['day'] == d and mins(t) - mins(WINS[-1]['slots'][-1]) <= 45: WINS[-1]['slots'].append(t)
    else: WINS.append(dict(day=d, et=t, slots=[t]))
for w in WINS:
    m = mins(w['et']) - 180; h = (m // 60) % 24; w['pt'] = f"{h % 12 or 12}:{m % 60:02d} {'PM' if h >= 12 else 'AM'}"
    w['lab'] = f"{DAB[w['day']]} {w['pt']}"
SLOTW = {(w['day'], t): i for i, w in enumerate(WINS) for t in w['slots']}
TEAMWIN = {}
for r in GW.itertuples():
    for tm in (r.home_team, r.away_team): TEAMWIN[T(tm)] = SLOTW[(r.weekday, r.gametime)]

# ---------------------------------------------------------------- Yahoo: Dom's four matchups (latest pull for this week)
def latest(pattern):
    f = sorted(glob.glob(pattern), key=os.path.getmtime); return f[-1] if f else None
YDIR = ROOT + f'yahoo/wk{WEEK}/'
MF = latest(YDIR + 'dom_matchups_*.txt'); SF = latest(YDIR + 'standings_*.txt'); WF = latest(YDIR + 'league_windows_*.txt')
def parse_side(s):
    out = []
    for it in s.split('|'):
        slot, name, team, st, ko, proj, pts = (it.split('^') + [''] * 7)[:7]
        name = re.sub(r'(No new player Notes|New Player Note|Player Notes?)$', '', name).strip()
        m = re.match(r"^(.*?)(Q|D|O|IR|SUS|PUP)$", name)
        if m and slot not in ('DEF',) and not name.endswith(('Jr', 'Sr', 'II', 'III', 'IV')): name, st = m.group(1), m.group(2)
        out.append(dict(slot=slot, player=name, team=T(team), status=st, kickoff=ko,
                        yahoo=float(proj) if proj not in ('', '–', '-') else None,
                        actual=float(pts) if pts not in ('', '–', '-') else None))
    return out
MATCH = {}
if MF:
    for line in open(MF):
        if line.startswith('#') or '#' not in line: continue
        lg, rest = line.rstrip('\n').split('#', 1); me, op = rest.split('##')
        MATCH[lg] = dict(me=parse_side(me), op=parse_side(op))
stamp('yahoo_matchups', MF, 26, rows=sum(len(v['me']) for v in MATCH.values()), need=sum(v['slots'] for v in LEAGUES.values()),
      note="Dom's four matchup pages, both sides, Yahoo proj + points")
# Yahoo's own win % and opponents from the all-teams sweep
YWIN, OPP, REC = {}, {}, {}
if WF:
    rows = [l.rstrip('\n').split('~') for l in open(WF) if not l.startswith('#') and l.strip()]
    for i in range(0, len(rows) - 1, 2):
        a, b = rows[i], rows[i + 1]
        for x, y in ((a, b), (b, a)):
            YWIN[(x[0], x[1])] = int(x[3]); OPP[(x[0], x[1])] = y[1]; REC[(x[0], x[1])] = x[2]
stamp('yahoo_all_teams', WF, 26, rows=len(YWIN), need=48, note='every team in all four leagues: Yahoo win %, record')
# standings: league rank, division rank, points for
STAND = {}
if SF:
    for line in open(SF):
        if line.startswith('#') or '#' not in line: continue
        lg, rest = line.rstrip('\n').split('#', 1); div = None; pos_in_div = 0; tbl = []
        for it in rest.split('|'):
            f = it.split('^')
            if len(f) == 1: div = f[0]; pos_in_div = 0; continue
            pos_in_div += 1
            nd = lg == '864215'
            tbl.append(dict(rank=int(f[0]), team=f[1], rec=f[2], div=div, div_rank=pos_in_div if div else None,
                            pf=float(f[3] if nd else f[4]), pa=float(f[4] if nd else f[5])))
        tb = pd.DataFrame(tbl); tb['pf_rank'] = tb.pf.rank(ascending=False, method='min').astype(int)
        STAND[lg] = tb
stamp('yahoo_standings', SF, 30, rows=sum(len(v) for v in STAND.values()), need=48, note='rank, division rank, points for')

# ---------------------------------------------------------------- Gotham
GST = ENGINE + 'gotham_status.json'
gs = json.load(open(GST)) if os.path.exists(GST) else {}
stamp('gotham', GST, 26, rows=gs.get('week'), need=WEEK, note=f"Gotham run {gs.get('run')} for week {gs.get('week')}")
if gs.get('week') != WEEK: alarms.append(f"gotham: built for week {gs.get('week')}, page is week {WEEK}")
GOT = {}
for lab in LEAGUES:
    f = ENGINE + f"gotham_{lab.replace(' ', '')}.csv"
    if os.path.exists(f):
        d = pd.read_csv(f); GOT[lab] = dict(zip(d.k.astype(str), d.eng_wk))

# ---------------------------------------------------------------- Sleeper (from Dom's GitHub feed job)
def newest_by_name(pattern):
    f = sorted(glob.glob(pattern)); return f[-1] if f else None      # job files carry their run time in the name
SKF = newest_by_name(FEEDS + f'proj/sleeper/wk{WEEK}_*.csv'); SKD = newest_by_name(FEEDS + f'proj/sleeper_kdef/wk{WEEK}_*.csv')
def ztime(p):
    m = re.search(r'_(\d{4}-\d{2}-\d{2})T(\d{4})Z', p or '')
    return dt.datetime.strptime(m.group(1) + m.group(2), '%Y-%m-%d%H%M').replace(tzinfo=dt.timezone.utc).astimezone(PT) if m else None
for key, p, need in (('sleeper_skill', SKF, 400), ('sleeper_kdef', SKD, 60)):
    n = len(pd.read_csv(p)) if p else 0
    stamp(key, p, 9999, rows=n, need=need, note='GitHub job run ' + (ztime(p).strftime('%a %I:%M %p PT') if p and ztime(p) else '?'))
    if p and ztime(p):
        age = round((NOW - ztime(p)).total_seconds() / 3600, 1)
        sources[key].update(pulled_pt=ztime(p).strftime('%a %b %d %I:%M %p PT'), age_h=age)
        if age > 6: sources[key]['status'] = 'STALE'; alarms.append(f'{key}: STALE - GitHub job file is {age} h old (limit 6 h; the job runs every 2 h)')
def sleeper_tables(k):
    sc = FM.SC[k]; key = [s for s in SCORING if s.startswith(['', 'DK I ', 'DK II ', 'DK III ', 'DK IV '][k])][0]; cfg = SCORING[key]
    sk = pd.read_csv(SKF).fillna(0); sk.columns = [c.lower() for c in sk.columns]
    sk['pts'] = (.04 * sk.pass_yd + sc['ptd'] * sk.pass_td + sc['it'] * sk.pass_int + .1 * sk.rush_yd + 6 * sk.rush_td + sc['ra'] * sk.rush_att
                 + sk.rec + .1 * sk.rec_yd + 6 * sk.rec_td - 2 * sk.fum_lost)
    S = dict(zip(sk.name.astype(str).map(norm), sk.pts))
    kd = pd.read_csv(SKD); KD = {}
    kc = cfg.get('K', {}); f40 = kc.get('fg40_49', 4); f50 = kc.get('fg50', 5); pm = kc.get('pat_miss', 0)
    pa = cfg.get('DEF_pa', [10, 7, 4, 1, 0, -1, -4])
    tiers = ('pts_allow_0', 'pts_allow_1_6', 'pts_allow_7_13', 'pts_allow_14_20', 'pts_allow_21_27', 'pts_allow_28_34', 'pts_allow_35p')
    for r in kd.itertuples():
        st = json.loads(r.stats)
        if r.pos == 'K':
            v = 3 * (st.get('fgm_0_19', 0) + st.get('fgm_20_29', 0) + st.get('fgm_30_39', 0)) + f40 * st.get('fgm_40_49', 0) + f50 * st.get('fgm_50p', 0) + st.get('xpm', 0) + pm * st.get('xpmiss', 0)
            KD[('K', norm(r.name))] = v
        else:
            v = sum(pa[i] * st.get(t, 0) for i, t in enumerate(tiers)) + st.get('sack', 0) + 2 * st.get('int', 0) + 2 * st.get('fum_rec', 0) + 6 * st.get('def_td', 0) + 2 * st.get('blk_kick', 0) + 2 * st.get('safe', 0)
            KD[('DEF', T(r.team))] = v
    return S, KD

# ---------------------------------------------------------------- per league
def pos_of(p):
    if p['slot'] in ('K', 'DEF'): return p['slot']
    return None
def side_var(players):
    s = [SIG.get(p['pos'], 8.0) for p in players if p['actual'] is None]
    ss = sum(x * x for x in s); st = sum(s); return ss + RHO * (st * st - ss)
def phi(z): return .5 * (1 + math.erf(z / math.sqrt(2)))
def chance(me, op, col):
    a = sum((p['actual'] if p['actual'] is not None else (p[col] or 0)) for p in me)
    b = sum((p['actual'] if p['actual'] is not None else (p[col] or 0)) for p in op)
    v = side_var(me) + side_var(op)
    if v <= 0: return a, b, (100 if a > b else 0 if a < b else 50)
    return a, b, round(100 * phi((a - b) / math.sqrt(v)))

POSMAP = {}
for f in glob.glob(ENGINE + 'gotham_*.csv'):
    d = pd.read_csv(f); POSMAP.update(dict(zip(d.k.astype(str), d.pos)))
RN = pd.read_csv(ROOT + 'rosters_nfl.csv', low_memory=False)
RN = RN[RN.week == RN.week.max()] if 'week' in RN else RN
POSMAP.update({norm(str(a)): b for a, b in zip(RN.full_name, RN.position) if str(a) != 'nan' and norm(str(a)) not in POSMAP})

LEAGUE_OUT, fallback_total = {}, 0
for lab, cfg in LEAGUES.items():
    if cfg['id'] not in MATCH: alarms.append(f'{lab}: no Yahoo matchup data for week {WEEK}'); continue
    S, KD = sleeper_tables(cfg['k']); gm = GOT.get(lab, {})
    sides = {}
    for side in ('me', 'op'):
        L = []
        for p in MATCH[cfg['id']][side]:
            k = norm(p['player']); pos = p['slot'] if p['slot'] in ('K', 'DEF') else POSMAP.get(k, p['slot'] if p['slot'] in SIG else 'WR')
            if pos in ('K', 'DEF'):
                sl = KD.get(('K', k)) if pos == 'K' else KD.get(('DEF', p['team']))
                go, gsrc = sl, 'sleeper'
            else:
                sl = S.get(k); go = gm.get(k); gsrc = 'gotham'
                if go is None or (isinstance(go, float) and math.isnan(go)):
                    go, gsrc = p['yahoo'], 'yahoo-fallback'; fallback_total += 1
            if sl is None: alarms.append(f"{lab}: no Sleeper number for {p['player']} ({pos}) - Yahoo used on the Sleeper needle")
            win = TEAMWIN.get(p['team'])
            L.append(dict(p, pos=pos, gotham=None if go is None else round(float(go), 2), gotham_src=gsrc,
                          sleeper=round(float(sl if sl is not None else (p['yahoo'] or 0)), 2), window=win))
        sides[side] = L
    me, op = sides['me'], sides['op']
    yt = chance(me, op, 'yahoo'); gt = chance(me, op, 'gotham'); st_ = chance(me, op, 'sleeper')
    def wins(L, col):
        w = [0.0] * len(WINS); c = [0] * len(WINS)
        for p in L:
            if p['window'] is None: continue
            w[p['window']] += (p['actual'] if p['actual'] is not None else (p[col] or 0)); c[p['window']] += 1
        return [round(x, 2) for x in w], c
    tb = STAND.get(cfg['id']); mine = tb[tb.team == cfg['me']].iloc[0].to_dict() if tb is not None and (tb.team == cfg['me']).any() else {}
    opp = OPP.get((cfg['id'], cfg['me'])); theirs = tb[tb.team == opp].iloc[0].to_dict() if tb is not None and opp and (tb.team == opp).any() else {}
    LEAGUE_OUT[lab] = dict(
        league=cfg['full'], league_id=cfg['id'], me=cfg['me'], opp=opp,
        record=mine.get('rec'), opp_record=theirs.get('rec'), rank=mine.get('rank'), div=mine.get('div'), div_rank=mine.get('div_rank'),
        pf_rank=mine.get('pf_rank'), teams=len(tb) if tb is not None else None, opp_rank=theirs.get('rank'),
        needles=dict(gotham=gt[2], yahoo=YWIN.get((cfg['id'], cfg['me'])), sleeper=st_[2], yahoo_from_spread=yt[2]),
        totals=dict(yahoo=[round(yt[0], 2), round(yt[1], 2)], gotham=[round(gt[0], 2), round(gt[1], 2)], sleeper=[round(st_[0], 2), round(st_[1], 2)]),
        windows=dict(me=wins(me, 'yahoo'), op=wins(op, 'yahoo')),
        played=dict(me=sum(1 for p in me if p['actual'] is not None), op=sum(1 for p in op if p['actual'] is not None), of=[len(me), len(op)]),
        starters=dict(me=me, op=op))
    if len(me) != cfg['slots'] or len(op) != cfg['slots']:
        alarms.append(f"{lab}: starters {len(me)}/{len(op)} - league starts {cfg['slots']}")
    for side, L in (('me', me), ('op', op)):
        for p in L:
            if p['window'] is None and p['team'] not in ('', None):
                (alarms if side == 'me' else notes).append(f"{lab}: {'YOUR' if side=='me' else 'opponent'} starter {p['player']} ({p['team']}) has no game this week")
            if p['gotham'] is not None and p['sleeper'] is not None and p['yahoo'] is not None and p['pos'] not in ('K','DEF'):
                outside = (p['yahoo'] + p['sleeper']) / 2
                if abs(p['gotham'] - outside) >= 6:
                    notes.append(f"{lab}: Gotham {p['gotham']:.1f} vs Yahoo {p['yahoo']:.1f} / Sleeper {p['sleeper']:.1f} on {p['player']} - check role/news")

os.makedirs(OUT, exist_ok=True)
meta = dict(week=WEEK, built_pt=NOW.strftime('%a %b %d %Y %I:%M %p PT'), windows=[w['lab'] for w in WINS],
            gotham_fallbacks=fallback_total, sources=sources, alarms=alarms, notes=notes, leagues=LEAGUE_OUT)
json.dump(meta, open(OUT + f'meter_wk{WEEK}.json', 'w'), indent=1, default=str)
json.dump(dict(week=WEEK, built_pt=meta['built_pt'], alarms=alarms, notes=notes, sources=sources), open(OUT + f'alarm_wk{WEEK}.json', 'w'), indent=1, default=str)
print(f'METER week {WEEK} built {meta["built_pt"]} | windows {meta["windows"]} | gotham fallbacks {fallback_total}')
for lab, v in LEAGUE_OUT.items():
    n = v['needles']; t = v['totals']
    print(f"{lab}: vs {v['opp']} ({v['opp_record']}) | {v['record']} rank {v['rank']} div {v['div_rank']} | GOTHAM {n['gotham']}% ({t['gotham'][0]}-{t['gotham'][1]})"
          f" | YAHOO {n['yahoo']}% ({t['yahoo'][0]}-{t['yahoo'][1]}) | SLEEPER {n['sleeper']}% ({t['sleeper'][0]}-{t['sleeper'][1]})")
for k, s in sources.items(): print(f"  source {k}: {s.get('status')} | {s.get('pulled_pt')} | age {s.get('age_h')} h | rows {s.get('rows')}/{s.get('need')}")
print('ALARMS:', len(alarms)); [print('  !', a) for a in alarms]
print('NOTES:', len(notes)); [print('  -', a) for a in notes]
